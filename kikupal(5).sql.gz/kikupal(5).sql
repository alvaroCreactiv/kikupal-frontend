-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-07-2018 a las 23:39:30
-- Versión del servidor: 10.1.29-MariaDB
-- Versión de PHP: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `kikupal`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrators`
--

CREATE TABLE `administrators` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_spanish_ci NOT NULL,
  `email` text COLLATE utf8_spanish_ci NOT NULL,
  `photo` text COLLATE utf8_spanish_ci,
  `password` text COLLATE utf8_spanish_ci NOT NULL,
  `profile` text COLLATE utf8_spanish_ci NOT NULL,
  `verificado` int(11) NOT NULL,
  `emailEncriptado` text COLLATE utf8_spanish_ci NOT NULL,
  `fechas` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `administrators`
--

INSERT INTO `administrators` (`id`, `name`, `email`, `photo`, `password`, `profile`, `verificado`, `emailEncriptado`, `fechas`) VALUES
(1, 'naomi', 'naomi@kikupal.com', 'vistas/img/Naomi-Bourgeois.jpg', '28bb9dae81f23e3e3ef399883fed3a23', 'admin', 0, 'b7cb244ed7305d86e3321a6ef6b626ff', '2018-06-11 16:17:27'),
(5, 'MultiServices One', 'info@one.com', NULL, '5a1ac3ea6adb8bc472100aa0d8f39818', 'provider', 1, '9b7f8d5dfea909c5a606c963a41aa336', '2018-06-12 18:46:53'),
(6, 'Creactivmedia', 'arturo_ruiz@creactivmedia.com.mx', NULL, '', 'provider', 1, '8db580a5689d442ff003d7d7a8fe339c', '2018-05-28 18:11:57'),
(7, 'lyft', 'info@gmail.com', NULL, '', 'provider', 1, '315874c5f7a60aa9b79a1f41bf5a959b', '2018-06-04 18:34:20'),
(8, 'Bussines S A', 'info@Bussines.com', NULL, '', 'provider', 1, 'c9e4ec0d550848acd23267ec95cd5b0c', '2018-06-11 15:46:22'),
(9, 'Tecglass', 'info@tecglass.com', NULL, '', 'provider', 1, '55b8788039c6120df8b7e91681d4b705', '2018-06-18 20:53:21'),
(12, 'Surtec', 'ivan@surtec.com', NULL, '494d6608723db8f52bf62f64ec7351e1', 'provider', 0, '37b144db0ed8c7e8e49d651b4ad5c9be', '2018-06-21 22:23:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contributor`
--

CREATE TABLE `contributor` (
  `id_contributor` int(11) NOT NULL,
  `cFname` text COLLATE utf8_spanish_ci NOT NULL,
  `cLname` text COLLATE utf8_spanish_ci NOT NULL,
  `cemail` text COLLATE utf8_spanish_ci NOT NULL,
  `cphone` int(12) NOT NULL,
  `visible` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `contributor`
--

INSERT INTO `contributor` (`id_contributor`, `cFname`, `cLname`, `cemail`, `cphone`, `visible`, `fecha`) VALUES
(22, 'Francisco', 'perez', 'angel@gmail.com', 789456123, 1, '2018-03-23 00:23:43'),
(23, 'Alvaro ', 'Villareal', 'jeperolim@gmail.com', 2147483647, 1, '2018-03-23 00:38:30'),
(24, 'Alvaro', 'Villarreal', 'alvaro@gmail.com', 2147483647, 1, '2018-03-23 16:12:31'),
(25, 'Claudia', 'quintanar', 'claudia@gmail.com', 789453212, 1, '2018-03-23 23:15:01'),
(26, 'alvaro', 'Villarreal', 'alvaro@gmail.com', 87654321, 1, '2018-03-23 23:17:38'),
(27, 'George', 'Gaitan', 'gaitan@gmail.com', 784561321, 1, '2018-03-27 18:19:49'),
(28, 'Alvaro', 'Villarreal', 'jeperolim@gmail.com', 123597874, 1, '2018-03-27 20:12:55'),
(29, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-03-27 20:15:32'),
(30, 'Alvaro', 'Villarreal', 'jeperolim@gmail.com', 789453211, 1, '2018-03-28 16:37:01'),
(31, 'Paola', 'Cordero', 'corde@gmail.com', 1235468454, 1, '2018-04-04 14:28:40'),
(32, 'Alvaro', 'Villarreal', 'jeperolim@gmail.com', 123548745, 1, '2018-04-06 22:03:52'),
(33, 'jan', 'per', 'per@gmail.com', 13549874, 1, '2018-04-06 22:38:18'),
(34, 'Pulido', 'alberto', 'pulido@gmail.com', 7896454, 1, '2018-04-06 22:55:29'),
(35, 'Pedro', 'Rmairez', 'pedro@hotmail.com', 78945212, 1, '2018-04-11 15:03:56'),
(36, 'Bulma', ' sandoval', 'bulma@gmail.com', 87654321, 1, '2018-04-16 16:18:07'),
(37, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 32365985, 1, '2018-04-16 17:46:16'),
(66, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-04-30 21:00:30'),
(67, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-04-30 21:01:32'),
(68, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-02 16:32:45'),
(69, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 987654621, 1, '2018-05-02 16:34:37'),
(70, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-02 23:23:13'),
(71, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-02 23:23:26'),
(72, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-02 23:24:31'),
(73, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 14:27:04'),
(74, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 14:56:41'),
(75, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:09:19'),
(76, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:11:59'),
(77, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-03 15:16:46'),
(78, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:17:50'),
(79, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:19:12'),
(80, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:20:26'),
(81, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:23:44'),
(82, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:34:35'),
(83, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-03 15:36:07'),
(84, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:39:07'),
(85, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:44:23'),
(86, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:45:07'),
(87, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:45:24'),
(88, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:46:41'),
(89, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:46:50'),
(90, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:49:15'),
(91, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:49:44'),
(92, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 54321, 1, '2018-05-03 15:52:02'),
(93, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:52:54'),
(94, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:54:45'),
(95, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:56:09'),
(96, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:57:39'),
(97, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:58:33'),
(98, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 15:58:56'),
(99, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:04:06'),
(100, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:05:36'),
(101, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:07:05'),
(102, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:09:19'),
(103, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:11:22'),
(104, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:13:35'),
(105, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:15:19'),
(106, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:16:07'),
(107, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:16:42'),
(108, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:16:53'),
(109, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:17:56'),
(110, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:18:11'),
(111, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:18:39'),
(112, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:29:38'),
(113, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 16:30:35'),
(114, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 17:20:59'),
(115, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 22:45:18'),
(116, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-03 23:11:58'),
(117, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 5436213, 1, '2018-05-03 23:25:24'),
(118, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-04 14:20:51'),
(119, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 865, 1, '2018-05-04 16:59:02'),
(120, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-04 17:20:41'),
(121, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-04 17:38:16'),
(122, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:05:57'),
(123, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:06:59'),
(124, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:08:01'),
(125, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:09:11'),
(126, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:09:23'),
(127, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:15:10'),
(128, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:25:37'),
(129, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 21321, 1, '2018-05-04 18:33:22'),
(130, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-05 17:33:51'),
(131, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-07 15:10:37'),
(132, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-07 17:13:42'),
(133, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-07 22:38:26'),
(134, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-07 23:14:14'),
(135, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-07 23:16:30'),
(136, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-07 23:21:47'),
(137, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-07 23:25:35'),
(138, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 15:55:06'),
(139, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 16:13:51'),
(140, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 16:15:53'),
(141, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 16:17:53'),
(142, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-08 18:05:29'),
(143, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-08 18:41:15'),
(144, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-08 18:46:12'),
(145, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 18:52:46'),
(146, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 19:05:45'),
(147, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 22:39:12'),
(148, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 22:42:26'),
(149, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-08 22:47:21'),
(150, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-08 23:10:28'),
(151, 'Julio alberto', 'Perez', 'julio@gmail.com', 85421065, 1, '2018-05-09 21:47:38'),
(152, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-09 22:41:01'),
(153, 'Alvaro', 'Villarreal', 'jepetolim05@gmail.com', 876545, 1, '2018-05-11 18:50:04'),
(154, 'Pakin', 'stone', 'stone@gmail.com', 45125648, 1, '2018-05-21 14:28:10'),
(155, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-21 14:36:47'),
(156, 'alberto', 'bora', 'borabora@gmail.com', 9765432, 1, '2018-05-21 14:41:54'),
(157, 'raul', 'arias', 'jepetolim@gmail.com', 789456412, 1, '2018-05-21 15:11:25'),
(158, 'Juan', 'Soto', 'soto@gmail.com', 54651, 1, '2018-05-21 18:10:41'),
(159, 'emmanuel', 'Arias', 'arias@gmail.com', 7945421, 1, '2018-05-21 18:39:29'),
(160, 'emmanuel', 'Arias', 'arias@gmail.com', 7945421, 1, '2018-05-21 18:40:00'),
(161, 'emmanuel', 'Arias', 'arias@gmail.com', 7945421, 1, '2018-05-21 18:40:05'),
(162, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-05-24 22:59:09'),
(163, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 2147483647, 1, '2018-05-31 20:36:33'),
(164, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-05-31 20:41:50'),
(165, 'Anonimous', 'Anonimous', 'Anonimous', 0, 0, '2018-06-04 18:15:17'),
(166, 'Juan ', 'pedro', 'jepetolim@gmail.com', 2147483647, 1, '2018-06-09 15:18:07'),
(167, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 0, 1, '2018-06-11 16:45:28'),
(168, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 2147483647, 1, '2018-06-11 21:12:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gifts`
--

CREATE TABLE `gifts` (
  `id` int(11) NOT NULL,
  `id_contributor` int(11) NOT NULL,
  `id_recipient` int(11) NOT NULL,
  `kikupoints` int(11) NOT NULL,
  `payment` text COLLATE utf8_spanish_ci NOT NULL,
  `status` int(11) NOT NULL,
  `note` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `gifts`
--

INSERT INTO `gifts` (`id`, `id_contributor`, `id_recipient`, `kikupoints`, `payment`, `status`, `note`, `fecha`) VALUES
(78, 37, 127, 100, '', 0, '', '2018-05-03 16:09:19'),
(79, 37, 132, 10, '', 0, '', '2018-05-03 16:11:23'),
(80, 37, 127, 20, '', 0, '', '2018-05-03 16:13:35'),
(81, 37, 127, 20, '', 0, '', '2018-05-03 16:15:19'),
(82, 37, 127, 20, '', 0, '', '2018-05-03 16:16:07'),
(83, 37, 127, 20, '', 0, '', '2018-05-03 16:16:42'),
(84, 37, 127, 120, '', 0, '', '2018-05-03 16:16:53'),
(85, 37, 127, 120, '', 0, '', '2018-05-03 16:17:56'),
(86, 37, 127, 60, '', 0, '', '2018-05-03 16:18:11'),
(87, 37, 127, 60, '', 0, '', '2018-05-03 16:18:39'),
(88, 37, 127, 25, '', 0, '', '2018-05-03 16:29:38'),
(89, 37, 128, 10, '', 0, '', '2018-05-03 16:30:35'),
(90, 37, 128, 250, '', 0, '', '2018-05-03 17:20:59'),
(91, 37, 131, 139, '', 0, '', '2018-05-03 22:45:19'),
(92, 37, 127, 32, '', 0, '', '2018-05-03 23:11:58'),
(93, 37, 128, 150, '', 0, '', '2018-05-03 23:25:24'),
(94, 37, 128, 100, '', 0, '', '2018-05-04 14:20:51'),
(95, 37, 127, 150, '', 0, '', '2018-05-04 16:59:02'),
(96, 37, 127, 120, '', 0, '', '2018-05-04 17:20:41'),
(97, 37, 127, 120, '', 0, '', '2018-05-04 17:38:17'),
(98, 37, 127, 100, '', 0, '', '2018-05-04 18:05:57'),
(99, 37, 127, 100, '', 0, '', '2018-05-04 18:06:59'),
(100, 37, 127, 100, '', 0, '', '2018-05-04 18:08:01'),
(101, 37, 127, 100, '', 0, '', '2018-05-04 18:09:11'),
(102, 37, 127, 100, '', 0, '', '2018-05-04 18:09:23'),
(103, 37, 127, 100, '', 0, '', '2018-05-04 18:15:10'),
(104, 37, 127, 100, '', 0, '', '2018-05-04 18:25:37'),
(105, 37, 127, 100, '', 0, '', '2018-05-04 18:33:22'),
(106, 29, 128, 310, '', 0, '', '2018-05-05 17:33:51'),
(107, 37, 127, 35, '', 0, '', '2018-05-07 15:10:37'),
(108, 37, 127, 21, '', 0, '', '2018-05-07 17:13:42'),
(109, 29, 128, 25, '', 0, '', '2018-05-07 22:38:26'),
(110, 29, 128, 25, '', 0, '', '2018-05-07 23:14:15'),
(111, 29, 128, 105, '', 0, '', '2018-05-07 23:16:30'),
(112, 37, 127, 30, '', 0, '', '2018-05-07 23:21:47'),
(113, 37, 132, 100, '', 0, '', '2018-05-07 23:25:35'),
(114, 29, 124, 20, '', 0, '', '2018-05-08 15:55:06'),
(115, 29, 128, 120, '', 0, '', '2018-05-08 16:13:51'),
(116, 29, 127, 205, '', 0, '', '2018-05-08 16:15:53'),
(117, 29, 124, 100, '', 0, '', '2018-05-08 16:17:53'),
(118, 37, 127, 100, '', 0, '', '2018-05-08 18:05:29'),
(119, 37, 132, 20, '', 0, '', '2018-05-08 18:41:16'),
(120, 37, 127, 100, '', 0, '', '2018-05-08 18:46:13'),
(121, 29, 127, 2, '', 0, '', '2018-05-08 18:52:46'),
(122, 29, 128, 100, '', 0, '', '2018-05-08 19:05:45'),
(123, 29, 128, 1, '', 0, '', '2018-05-08 22:39:12'),
(124, 29, 128, 2, '', 0, '', '2018-05-08 22:42:27'),
(125, 29, 132, 3, 'paypal', 1, '', '2018-05-08 22:47:43'),
(126, 37, 133, 100, 'paypal', 1, '', '2018-05-08 23:10:54'),
(127, 151, 135, 101, 'paypal', 1, '', '2018-05-09 21:48:24'),
(128, 37, 134, 34, 'paypal', 1, '', '2018-05-09 22:41:42'),
(129, 153, 134, 20, 'paypal', 1, '', '2018-05-11 18:52:33'),
(130, 154, 140, 30, 'paypal', 1, '', '2018-06-09 16:57:53'),
(131, 29, 139, 100, 'paypal', 1, '', '2018-05-21 14:38:19'),
(132, 156, 139, 60, 'paypal', 1, '', '2018-05-21 14:42:39'),
(133, 157, 139, 100, 'paypal', 1, '', '2018-05-21 15:11:57'),
(134, 158, 141, 100, 'paypal', 1, '', '2018-05-21 18:11:50'),
(135, 159, 142, 60, '', 0, '', '2018-05-21 18:39:29'),
(136, 159, 142, 60, '', 0, '', '2018-05-21 18:40:00'),
(137, 159, 142, 60, '', 0, '', '2018-05-21 18:40:05'),
(138, 29, 127, 100, '', 0, '', '2018-05-24 22:59:09'),
(139, 37, 128, 60, 'paypal', 1, '', '2018-05-31 20:37:30'),
(140, 37, 131, 100, 'paypal', 1, '', '2018-05-31 20:42:13'),
(141, 29, 128, 150, 'paypal', 1, '', '2018-06-04 18:16:05'),
(142, 166, 128, 37, 'paypal', 1, '', '2018-06-09 15:18:39'),
(143, 37, 128, 100, 'paypal', 1, '', '2018-06-11 16:48:45'),
(144, 37, 143, 250, '', 0, 'cuidate', '2018-06-11 21:12:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impuestos`
--

CREATE TABLE `impuestos` (
  `id` int(11) NOT NULL,
  `nombre` text COLLATE utf8_spanish_ci NOT NULL,
  `impuesto` float NOT NULL,
  `ModePaypal` text COLLATE utf8_spanish_ci NOT NULL,
  `clientIdPaypal` text COLLATE utf8_spanish_ci NOT NULL,
  `SecretPaypal` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `impuestos`
--

INSERT INTO `impuestos` (`id`, `nombre`, `impuesto`, `ModePaypal`, `clientIdPaypal`, `SecretPaypal`) VALUES
(1, 'Paypal\'s Fees', 2.9, 'sandbox', 'AZXR6zARCzeOZcvNw9meGtWyrAMnJsPcYUtvv5TstFR_al22mcfAtZuZ8vmCWzvg4cbdj56lNJd4R6_V', 'EG4ZvGk5JYufEBhaPys0ZuejFLuxyoeG9DdbmvZJqraUfexO-hR8abedvFlpNLscQoecfXp1oojhaLpz');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plantilla`
--

CREATE TABLE `plantilla` (
  `id` int(11) NOT NULL,
  `barraSuperior` text COLLATE utf8_spanish_ci NOT NULL,
  `textoSuperior` text COLLATE utf8_spanish_ci NOT NULL,
  `colorFondo` text COLLATE utf8_spanish_ci NOT NULL,
  `colorTexto` text COLLATE utf8_spanish_ci NOT NULL,
  `logo` text COLLATE utf8_spanish_ci NOT NULL,
  `icono` text COLLATE utf8_spanish_ci NOT NULL,
  `video` text COLLATE utf8_spanish_ci NOT NULL,
  `redesSociales` text COLLATE utf8_spanish_ci NOT NULL,
  `apiFacebook` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `plantilla`
--

INSERT INTO `plantilla` (`id`, `barraSuperior`, `textoSuperior`, `colorFondo`, `colorTexto`, `logo`, `icono`, `video`, `redesSociales`, `apiFacebook`, `fecha`) VALUES
(1, '#ce0c5b', '#ffffff', '#29b6ac', '#ffffff', 'vistas/img/plantilla/logo.png', 'vistas/img/plantilla/icono.png', 'vistas/vid/texas.mp4', '[{\"red\":\"fa-facebook\",\"estilo\":\"facebookColor\",\"url\":\"https://www.facebook.com/MyKikupal/\",\"activo\":1},{\"red\":\"fa-youtube\",\"estilo\":\"youtubeColor\",\"url\":\"http://www.youtube.com\",\"activo\":1},{\"red\":\"fa-twitter\",\"estilo\":\"twitterColor\",\"url\":\"\",\"activo\":0},{\"red\":\"fa-google-plus\",\"estilo\":\"google-plusColor\",\"url\":\"\",\"activo\":0},{\"red\":\"fa-instagram\",\"estilo\":\"instagramColor\",\"url\":\"\",\"activo\":0}]', '<script>   window.fbAsyncInit = function() {     FB.init({       appId      : \\\'217066325510400\\\',       cookie     : true,       xfbml      : true,       version    : \\\'v2.12\\\'     });            FB.AppEvents.logPageView();             };    (function(d, s, id){      var js, fjs = d.getElementsByTagName(s)[0];      if (d.getElementById(id)) {return;}      js = d.createElement(s); js.id = id;      js.src = \\\"https://connect.facebook.net/en_US/sdk.js\\\";      fjs.parentNode.insertBefore(js, fjs);    }(document, \\\'script\\\', \\\'facebook-jssdk\\\'));  </script>', '2018-06-22 18:48:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provider`
--

CREATE TABLE `provider` (
  `id_provider` int(11) NOT NULL,
  `type` text COLLATE utf8_spanish_ci NOT NULL,
  `companyName` text COLLATE utf8_spanish_ci NOT NULL,
  `companyAddress` text COLLATE utf8_spanish_ci NOT NULL,
  `companyWebSite` text COLLATE utf8_spanish_ci NOT NULL,
  `contacName` text COLLATE utf8_spanish_ci NOT NULL,
  `phoneNumber` int(11) NOT NULL,
  `email` text COLLATE utf8_spanish_ci NOT NULL,
  `verificacion` int(11) NOT NULL,
  `emailEncriptado` text COLLATE utf8_spanish_ci NOT NULL,
  `enable` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `provider`
--

INSERT INTO `provider` (`id_provider`, `type`, `companyName`, `companyAddress`, `companyWebSite`, `contacName`, `phoneNumber`, `email`, `verificacion`, `emailEncriptado`, `enable`, `date`) VALUES
(27, '4', 'MultiServices One', 'sta cecilia', 'one.com.mx', 'John smith', 876513213, 'info@one.com', 1, '9b7f8d5dfea909c5a606c963a41aa336', 0, '2018-06-11 21:39:31'),
(28, '6', 'Creactivmedia', 'avenida angel leano', 'creactivmedia.com.mx', 'arturo Ruiz', 2147483647, 'arturo_ruiz@creactivmedia.com.mx', 1, '8db580a5689d442ff003d7d7a8fe339c', 0, '2018-05-28 18:11:57'),
(29, '5', 'lyft', 'sn. Luis', 'lyft.com', 'John smith', 21321545, 'info@gmail.com', 1, '315874c5f7a60aa9b79a1f41bf5a959b', 0, '2018-06-04 18:34:19'),
(30, '6', 'Bussines S A', 'st. monica California', 'Bussines .com', 'Juan peroro', 32135321, 'info@Bussines.com', 1, 'c9e4ec0d550848acd23267ec95cd5b0c', 0, '2018-06-11 15:46:22'),
(31, '4', 'Tecglass', 'Av. de la paz', 'tecglass.com', 'jose luis uraga', 7896546, 'info@tecglass.com', 1, '55b8788039c6120df8b7e91681d4b705', 0, '2018-06-18 20:53:21'),
(34, '4', 'Surtec', 'first av. lomas', 'surtec.com', 'ivan basso', 87954654, 'ivan@surtec.com', 1, '37b144db0ed8c7e8e49d651b4ad5c9be', 0, '2018-06-21 18:45:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recipient`
--

CREATE TABLE `recipient` (
  `id_recipient` int(11) NOT NULL,
  `bFname` text COLLATE utf8_spanish_ci NOT NULL,
  `bLname` text COLLATE utf8_spanish_ci NOT NULL,
  `bemail` text COLLATE utf8_spanish_ci NOT NULL,
  `bphone` int(12) NOT NULL,
  `bdescription` text COLLATE utf8_spanish_ci NOT NULL,
  `bphoto` text COLLATE utf8_spanish_ci NOT NULL,
  `modo` text COLLATE utf8_spanish_ci NOT NULL,
  `verificacion` int(11) NOT NULL,
  `emailEncriptado` text COLLATE utf8_spanish_ci NOT NULL,
  `direccion` text COLLATE utf8_spanish_ci NOT NULL,
  `password` text COLLATE utf8_spanish_ci NOT NULL,
  `Fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `recipient`
--

INSERT INTO `recipient` (`id_recipient`, `bFname`, `bLname`, `bemail`, `bphone`, `bdescription`, `bphoto`, `modo`, `verificacion`, `emailEncriptado`, `direccion`, `password`, `Fecha`) VALUES
(124, 'Laura', 'Pena', 'rarjona@gmail.com', 10504588, 'Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laboru\r\n                        \r\n                        ', 'vistas/img/recipients/124/808.jpg', 'directo', 0, '4ce3cf18207c123b3397c1047672a663', 'valle real, zapopan jalisco', '92439e6d918fc4ae9e6be1bebd73454e', '2018-03-26 22:49:11'),
(127, 'claudia', 'quintanar', 'claudia@reactiv.com', 1254565421, 'Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n                        ', 'vistas/img/recipients/127/464.jpg', 'directo', 0, '90858675563544c13b88fb459d034e47', 'Av. san felipe', 'd323bc79615a8dc5bc337bbf9c38598c', '2018-06-13 23:31:07'),
(128, 'Arturo', 'Ruiz ', 'arturo_ruiz@creactivmedia.com.mx', 865143213, 'Me duele la cabeza\r\n                        ', 'vistas/img/recipients/128/986.jpg', 'directo', 0, '8db580a5689d442ff003d7d7a8fe339c', 'Juan Gil Precioado', 'f19399d233af0b48936ec02742ef7cd6', '2018-06-22 15:15:14'),
(131, 'Porfirio', 'Diaz', 'dias@gmail.com', 7894531, 'is my name for ever\r\n                        \r\n                        \r\n                        \r\n                        \r\n                        \r\n                        \r\n                        \r\n                        \r\n                        ', 'vistas/img/recipients/131/850.jpg', 'directo', 0, 'e09bb311bfd5b5f66915aaf2b3d4ef04', 'Juan Gil preciado No 22', '868310c023ef93de5db48a7bf83178a9', '2018-04-03 18:06:05'),
(139, 'Jose', 'Perez', 'perez@gmail.com', 546251, '', '', 'directo', 1, '9ddc9bcb5e6f19150c1d92d9919b2341', '', '', '2018-05-15 21:25:49'),
(140, 'Pakin', 'stone', 'stone@gmail.com', 45125648, '', '', 'directo', 1, '5dde957e31c1b67ecb5a1b10decce810', '', '', '2018-05-21 14:27:05'),
(141, 'Juan', 'Soto', 'soto@gmail.com', 54651, '', '', 'directo', 1, '464dc681db2bbf3f3e61681b17b1bfda', '', '', '2018-05-21 18:10:17'),
(142, 'emmanuel', 'Arias', 'arias@gmail.com', 7945421, '', '', 'directo', 1, '808c5d6ec6d2065678e391c9b2ac96de', '', '', '2018-05-21 18:39:15'),
(143, 'Jessica ', 'De la Rosa', 'jesica@gmail.com', 2147483647, 'Tuvo un accidente y necesita ayuda\r\n                        ', 'vistas/img/recipients/143/575.jpg', 'directo', 0, '7be773283ff3671382a9185f21ed9d6f', 'santa  lucia sn zapopan', 'f6f003a3fa84ebd66807b748052b3cfa', '2018-06-11 21:20:36'),
(144, 'Alvaro', 'Villarreal', 'jepetolim@gmail.com', 87854, '', '', 'directo', 1, '3611bf5162d7e6a575d127732c96e54f', '', '', '2018-06-29 17:46:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `scheduleservice`
--

CREATE TABLE `scheduleservice` (
  `id` int(11) NOT NULL,
  `id_service` int(11) NOT NULL,
  `id_recipient` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `amount` float NOT NULL,
  `id_provider` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `comment` text COLLATE utf8_spanish_ci NOT NULL,
  `creado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `scheduleservice`
--

INSERT INTO `scheduleservice` (`id`, `id_service`, `id_recipient`, `fecha`, `hora`, `amount`, `id_provider`, `status`, `rate`, `comment`, `creado`) VALUES
(1, 6, 128, '2018-04-13', '01:45:00', 40, 27, 1, 2, 'Sin comentarios', '2018-06-08 22:45:29'),
(2, 6, 128, '2018-04-29', '01:45:00', 40, 29, 1, 5, 'Sin comentarios', '2018-06-08 22:47:42'),
(9, 6, 127, '2018-04-27', '08:00:00', 105, 29, 1, 0, '', '2018-06-08 22:16:47'),
(10, 6, 127, '2018-04-20', '12:00:00', 100, 1, 0, 0, 'Sin comentarios', '2018-04-23 22:15:14'),
(11, 6, 128, '2018-04-15', '11:00:00', 65, 27, 0, 0, 'dfgdfgsdf', '2018-05-28 17:46:22'),
(12, 6, 128, '2018-04-15', '10:00:00', 105, 27, 0, 0, 'Sin comentarios', '2018-05-28 17:46:58'),
(23, 6, 127, '2018-04-28', '06:00:00', 105, 15, 0, 0, '', '2018-05-25 23:54:46'),
(24, 6, 127, '2018-04-27', '09:30:00', 105, 4, 0, 0, '', '2018-05-25 23:54:58'),
(25, 6, 128, '2018-04-26', '01:00:00', 105, 28, 1, 3, '', '2018-06-08 22:48:07'),
(26, 6, 127, '2018-05-19', '12:00:00', 65, 15, 0, 0, '', '2018-05-14 15:20:36'),
(27, 6, 128, '2018-05-25', '10:15:00', 40, 28, 0, 0, '', '2018-05-28 18:19:06'),
(28, 6, 128, '2018-06-07', '12:00:00', 40, 27, 0, 0, '', '2018-06-04 18:22:48'),
(29, 6, 143, '2018-06-13', '04:15:00', 105, 27, 1, 5, '', '2018-06-11 21:19:23'),
(30, 6, 128, '2018-06-14', '10:00:00', 40, 30, 1, 5, '', '2018-06-12 18:34:11'),
(31, 6, 128, '2018-07-13', '11:30:00', 105, 0, 0, 0, '', '2018-07-05 16:32:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `services`
--

CREATE TABLE `services` (
  `id_service` int(11) NOT NULL,
  `name` text COLLATE utf8_spanish_ci NOT NULL,
  `photo` text COLLATE utf8_spanish_ci NOT NULL,
  `cost` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `services`
--

INSERT INTO `services` (`id_service`, `name`, `photo`, `cost`) VALUES
(4, 'Meals', 'vistas/img/items/meals.jpg', 0),
(5, 'House Cleaning', 'vistas/img/items/housecleaning.jpg', 95),
(6, 'Yard Care', 'vistas/img/items/yardCare01.jpg', 40),
(7, 'Concierge', 'vistas/img/items/concierge.jpg', 0),
(8, 'Transport', 'vistas/img/items/transport.jpg', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_spanish_ci NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `name`, `type`) VALUES
(1, 'administrator', 1),
(2, 'recipient', 2),
(3, 'servicesProvider', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_spanish_ci NOT NULL,
  `path` text COLLATE utf8_spanish_ci NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `videos`
--

INSERT INTO `videos` (`id`, `name`, `path`, `status`) VALUES
(1, 'promo', 'vistas/vid/texas.mp4', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrators`
--
ALTER TABLE `administrators`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `contributor`
--
ALTER TABLE `contributor`
  ADD PRIMARY KEY (`id_contributor`);

--
-- Indices de la tabla `gifts`
--
ALTER TABLE `gifts`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `plantilla`
--
ALTER TABLE `plantilla`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id_provider`);

--
-- Indices de la tabla `recipient`
--
ALTER TABLE `recipient`
  ADD PRIMARY KEY (`id_recipient`);

--
-- Indices de la tabla `scheduleservice`
--
ALTER TABLE `scheduleservice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_recipient` (`id_recipient`),
  ADD KEY `id_provider` (`id_provider`),
  ADD KEY `id_service` (`id_service`) USING BTREE;

--
-- Indices de la tabla `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id_service`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrators`
--
ALTER TABLE `administrators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `contributor`
--
ALTER TABLE `contributor`
  MODIFY `id_contributor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT de la tabla `gifts`
--
ALTER TABLE `gifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT de la tabla `impuestos`
--
ALTER TABLE `impuestos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `provider`
--
ALTER TABLE `provider`
  MODIFY `id_provider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de la tabla `recipient`
--
ALTER TABLE `recipient`
  MODIFY `id_recipient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT de la tabla `scheduleservice`
--
ALTER TABLE `scheduleservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `services`
--
ALTER TABLE `services`
  MODIFY `id_service` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `scheduleservice`
--
ALTER TABLE `scheduleservice`
  ADD CONSTRAINT `scheduleservice_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `services` (`id_service`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
